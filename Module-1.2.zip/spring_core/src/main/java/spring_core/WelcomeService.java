package spring_core;

import org.springframework.stereotype.Component;

@Component
public class WelcomeService {
    public String getWelcomeMessage() {
        return "hello world";
    }
}
