package spring_core;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        // Create the application context using the AppConfig class
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        
        // Retrieve the WelcomeService bean
        WelcomeService welcomeService = context.getBean(WelcomeService.class);
        
        // Print the welcome message
        System.out.println(welcomeService.getWelcomeMessage());
        
        // Close the application context
        context.close();
    }
}
